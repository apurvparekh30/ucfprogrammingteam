n,s = map(int, raw_input().split())
h = max(map(int, raw_input().split()))
print (h*s+1000-1)/1000