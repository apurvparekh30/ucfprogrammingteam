// Arup Guha
// 2/4/2016
// Solution to 2014 Mercer Programming Contest Problem #6: The Disgruntled Professor

import java.util.*;

public class prob6 {

	public static int n;
	public static int[] data;
	public static double[] avgFromLeft;
	public static double[] avgFromRight;

	public static void main(String[] args) {

		Scanner stdin = new Scanner(System.in);
		n = stdin.nextInt();
		data = new int[n];

		// Read in data cyclically shifted right.
		for (int i=0; i<n; i++)
			data[i] = stdin.nextInt();

		// Solve and output result.
		System.out.printf("%.3f\n", solve());
	}

	// Returns the solution to the instance of the problem.
	public static double solve() {

		// Set up binary search, we know, at worst case, we can take the first and last values.
		double high = (data[0]+data[n-1])/2.0;
		double low = 0, mid = 0;

		// Run a binary search
		while (high-low > 1e-9) {
			mid = (low+high)/2;
			if (possible(mid))	high = mid;
			else				low = mid;
		}

		// Here is our result.
		return mid;
	}

	// Returns true iff it's possible to have a consecutive run of numbers including data[0], data[n-1] that has an
	// average of x or less.
	public static boolean possible(double x) {

		// Offset each term by average. (So, if sum <= 0, then x is a possible answer.)
		double[] tmp = new double[n];
		for (int i=0; i<n; i++)
			tmp[i] = data[i] - x;

		// Calculate, for each index, the minimum sum up to it, from the left side.
		// Thus, minSumFromLeft[i] = min(tmp[0], tmp[0]+tmp[1], tmp[0]+tmp[1]+tmp[2],...,tmp[0]+...+tmp[i]).
		double[] minSumFromLeft = new double[n];
		minSumFromLeft[0] = tmp[0];
		double sum = tmp[0];
		for (int i=1; i<n; i++) {
			sum += tmp[i];
			minSumFromLeft[i] = Math.min(minSumFromLeft[i-1], sum);
		}

		// Now, do the same from the right.
		double[] minSumFromRight = new double[n];
		minSumFromRight[n-1] = tmp[n-1];
		sum = tmp[n-1];
		for (int i=n-2; i>=0; i--) {
			sum += tmp[i];
			minSumFromRight[i] = Math.min(minSumFromRight[i+1], sum);
		}

		// Now sweep through data, seeing if there's ever a cut point where we can get a non-poositive sum with
		// sum numbers on the left and right.
		double cur = 0;
		for (int i=0; i<n-2; i++)
			if (minSumFromLeft[i] + minSumFromRight[i+2] <= 1e-7) return true;

		// If we get here, we never found a suitable cut point.
		return false;
	}
}
