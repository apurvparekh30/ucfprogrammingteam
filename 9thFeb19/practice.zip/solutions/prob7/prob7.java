// Arup Guha
// 3/7/3014
// Solution to 2014 Mercer Programming Contest Problem 7: Trending on Twitter

import java.util.*;

public class prob7 {

	public static void main(String[] args) {

		Scanner stdin = new Scanner(System.in);
		int numLines = Integer.parseInt(stdin.nextLine());

		// Will store each hashtag here.
		HashMap<String,Integer> map = new HashMap<String,Integer>();

		// Go through each tweet.
		for (int i=0; i<numLines; i++) {

			String tweet = stdin.nextLine();
			StringTokenizer tok = new StringTokenizer(tweet);

			// Go through each token.
			while (tok.hasMoreTokens()) {

				String token = tok.nextToken();

				// This is a hashtag!
				String tag = getHashtag(token);
				if (tag != null) {

					// We've seen this one before, so update.
					if (map.containsKey(tag)) {
						int times = map.get(tag);
						map.put(tag, times+1);
					}

					// It it to our map.
					else
						map.put(tag, 1);
				}
			}

			// Skip blank line.
			if (stdin.hasNext()) stdin.nextLine();
		}

		// Store all tags here.
		pair[] all = new pair[map.size()];
		int index = 0;
		for (String s: map.keySet())
			all[index++] = new pair(s, map.get(s));

		// Sort and output.
		Arrays.sort(all);
		for (int i=0; i<all.length; i++)
			System.out.println(all[i]);
	}

	// Returns true iff s is a hashtag.
	public static String getHashtag(String s) {

		// Rule #1.
		if (s.charAt(0) != '#') return null;

		// Strip ending non-alphabetic characters.
		String tmp = s.substring(1).toLowerCase();
		int i;
		for (i=0; i<tmp.length(); i++)
			if (tmp.charAt(i) < 'a' || tmp.charAt(i) > 'z')
				break;

		// Return this.
		return tmp.substring(0, i);
	}
}

class pair implements Comparable<pair> {

	public String word;
	public int freq;

	public pair(String s, int f) {
		word = s;
		freq = f;
	}

	// Sorting scheme problem requests.
	public int compareTo(pair other) {
		if (other.freq != this.freq)
			return other.freq - this.freq;
		return word.compareTo(other.word);
	}

	// Output problem requests.
	public String toString() {
		return freq+" "+word;
	}
}
