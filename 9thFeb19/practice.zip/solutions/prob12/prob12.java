// Arup Guha
// 3/3/2014
// Solution to 2014 Mercer Contest Problem 12: What? Where? When?
/*** Note: My solution produces output that is slightly different than the posted judge data.
 *         All discrepancies are in the last digit of precision. Upon reviewing the first
 * 	       discrepancy, it was discovered that the exact correct answer was 84/512 = 21/128
 *         which is exactly .1640625, which should be printed as .164063 not .164062. My
 *         solution produces the former correct result while the judge solution produces
 *         the latter result. Thus, I feel that this solution is valid. I have carefully coded
 *         before looking at the judge data for this sort of case by adding EPSILON before
 *         printing. I also inspected all discrepancies, which were 1312/4096, 416/4096 and 100/512
 *         all of which should round up, as this solution does.
 ***/

import java.util.*;

public class prob12 {

	final public static double EPSILON = 0.0000000001;

	public static void main(String[] args) {

		Scanner stdin = new Scanner(System.in);
		int numCases = stdin.nextInt();

		for (int loop=0; loop<numCases; loop++) {

			int n = stdin.nextInt();
			int k = stdin.nextInt();

			// Read in this mask.
			int mask = 0;
			for (int i=0; i<n; i++)
				mask = (mask << 1) + stdin.nextInt();

			// Solve and output result.
			double[] ans = solve(mask, n, k);
			for (int i=ans.length-1; i>0; i--)
				System.out.printf("%.6f ", ans[i]+EPSILON);
			System.out.printf("%.6f\n", ans[0]+EPSILON);
		}
	}

	public static double[] solve(int mask, int n, int k) {

		int startBits = Integer.bitCount(mask);

		// Weird impossible answer.
		if (k > startBits) return new double[n];

		// Set up BFS through set of possible bitmasks (subsets of reachable envelopes)
		HashMap<Integer,Double> map = new HashMap<Integer,Double>();
		LinkedList<Integer> q = new LinkedList<Integer>();
		double[] ans = new double[n];
		map.put(mask, 1.0);
		q.offer(mask);

		// I'll stop when nothing else of importance is in the queue.
		while (q.size() > 0) {

			int next = q.poll();

			// This is leading into the correct round...
			if (Integer.bitCount(next) == startBits-k+1) {

				// Try each bit as the next one.
				for (int i=0; i<n; i++)
					ans[i] += (map.get(next)*getProb(next, i, n));
			}
			else {

				// Try removing each bit...
				for (int i=0; i<n; i++) {

					// This bit is possible.
					if (((next >> i) & 1) > 0) {

						// Probability of getting here.
						double p = map.get(next)*getProb(next, i, n);

						// New subset, so add it to our map.
						if (!map.containsKey(next - (1 << i))) {
							map.put(next - (1 << i), p);
							q.offer(next - (1 << i));
						}
						// We have this one, so add to its probability.
						else  {
							double curP = map.get(next - (1 << i));
							map.put(next - (1 << i), curP+p);
						}
					}
				} // end for
			} // end if-else
		} // end while (bfs)

		return ans;
	}

	public static double getProb(int state, int bit, int n) {

		// Bit is already off, can't happen.
		if (((state >> bit) & 1) == 0) return 0;

		// Loop from bit till you get to the next 1, cyclically.
		int prev = (bit + 1)%n;
		int cnt = 1;
		while (((state >> prev) & 1) == 0) {
			cnt++;
			prev = (prev + 1)%n;
		}
		return ((double)cnt)/n;
	}
}
