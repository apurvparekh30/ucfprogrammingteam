// Arup Guha
// 3/17/2014
// This program calculates exact fractions for each probability and prints these out
// without an added EPSILON. These answers match my original solution, prob12.java.

import java.util.*;

public class prob12b {

	public static void main(String[] args) {

		Scanner stdin = new Scanner(System.in);
		int numCases = stdin.nextInt();

		for (int loop=0; loop<numCases; loop++) {

			int n = stdin.nextInt();
			int k = stdin.nextInt();

			// Read in this mask.
			int mask = 0;
			for (int i=0; i<n; i++)
				mask = (mask << 1) + stdin.nextInt();

			// Solve and output result.
			long[] ans = solve(mask, n, k);

			// Print out result.
			for (int i=ans.length-1; i>0; i--)
				System.out.printf("%.6f ", (double)ans[i]/power(n,k));
			System.out.printf("%.6f\n", (double)ans[0]/power(n,k));
		}
	}

	// Accurate power function.
	public static long power(int base, int exp) {
		long ans = 1;
		for (int i=0; i<exp; i++)
			ans *= base;
		return ans;
	}

	public static long[] solve(int mask, int n, int k) {

		int startBits = Integer.bitCount(mask);

		// Weird impossible answer.
		if (k > startBits) return new long[n];

		// Set up BFS through set of possible bitmasks (subsets of reachable envelopes)
		HashMap<Integer,Long> map = new HashMap<Integer,Long>();
		LinkedList<Integer> q = new LinkedList<Integer>();
		long[] ans = new long[n];
		map.put(mask, 1L);
		q.offer(mask);

		// I'll stop when nothing else of importance is in the queue.
		while (q.size() > 0) {

			int next = q.poll();

			// This is leading into the correct round...
			if (Integer.bitCount(next) == startBits-k+1) {

				// Try each bit as the next one.
				for (int i=0; i<n; i++)
					ans[i] += (map.get(next)*getProb(next, i, n));
			}
			else {

				// Try removing each bit...
				for (int i=0; i<n; i++) {

					// This bit is possible.
					if (((next >> i) & 1) > 0) {

						// Probability of getting here.
						long p = map.get(next)*getProb(next, i, n);

						// New subset, so add it to our map.
						if (!map.containsKey(next - (1 << i))) {
							map.put(next - (1 << i), p);
							q.offer(next - (1 << i));
						}
						// We have this one, so add to its probability.
						else  {
							long curP = map.get(next - (1 << i));
							map.put(next - (1 << i), curP+p);
						}
					}
				} // end for
			} // end if-else
		} // end while (bfs)

		return ans;
	}

	public static int getProb(int state, int bit, int n) {

		// Bit is already off, can't happen.
		if (((state >> bit) & 1) == 0) return 0;

		int prev = (bit + 1)%n;
		int cnt = 1;
		while (((state >> prev) & 1) == 0) {
			cnt++;
			prev = (prev + 1)%n;
		}
		return cnt;
	}
}
