// Arup Guha
// 3/1/2014
// Solution to 2014 Mercer Contest Problem 10: Candies To Go

import java.util.*;

public class prob10 {

	public static int[][][] memo;

	public static void main(String[] args) {

		Scanner stdin = new Scanner(System.in);
		int numCases = stdin.nextInt();

		// Go through cases.
		for (int loop=0; loop<numCases; loop++) {

			int n = stdin.nextInt();
			int W = stdin.nextInt();

			// Read in data.
			int[] weights = new int[n];
			int[] scores = new int[n];
			for (int i=0; i<n; i++)
				weights[i] = stdin.nextInt();
			for (int i=0; i<n; i++)
				scores[i] = stdin.nextInt();

			// Set up memo and solve.
			memo = new int[n][W+1][W+1];
			for (int i=0; i<n; i++)
				for (int j=0; j<=W; j++)
					Arrays.fill(memo[i][j], -1);
			System.out.println(solve(weights, scores, W));
		}
	}

	public static int solve(int[] weights, int[] scores, int maxW) {
		return solveRec(weights, scores, 0, maxW, 0, 0, 0);
	}

	public static int solveRec(int[] weights, int[] scores, int k, int maxW, int prevQ, int curW, int curS) {

		// We've solved this case, return it's answer.
		if (k == weights.length) return curS;

		// We go over our weight limit if we give kid k the minimum amount of candy.
		if (prevQ > 0 && weights[k]*(prevQ+1)+curW > maxW) return -1;

		// We have solved this before.
		if (memo[k][curW][prevQ] != -1) return memo[k][curW][prevQ];

		int best = 0;
		int startQ = 0;
		if (prevQ > 0) startQ = prevQ+1;

		// Try each possible quantity of candy for kid k.
		for (int q=startQ;; q++) {
			if (curW+weights[k]*q > maxW) break;
			int tmp = solveRec(weights, scores, k+1, maxW, q, curW+weights[k]*q, curS+scores[k]*q);
			if (tmp > best) best = tmp;
		}

		// Store and return.
		memo[k][curW][prevQ] = best;
		return best;
	}
}

