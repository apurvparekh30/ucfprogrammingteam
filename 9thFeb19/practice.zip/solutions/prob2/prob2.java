// Arup Guha
// 3/1/2014
// Solution to 2014 Mercer Contest Problem 2: Sub-Diagonal Paths - written in contest

import java.util.*;

public class prob2 {

	public static void main(String[] args) {

		// Store Catalan Numbers here.
		long[] f = new long[31];
		f[0] = 1;
		f[1] = 1;

		// This is the recurrence.
		for (int i=2; i<=30; i++)
			for (int j=0; j<i; j++)
				f[i] += (f[j]*f[i-1-j]);

		// Answer queries.
		Scanner stdin = new Scanner(System.in);
		int n = stdin.nextInt();
		while (n !=0) {
			System.out.println(f[n]);
			n = stdin.nextInt();
		}
	}

}
