// Arup Guha
// 3/1/2014
// Solution to 2014 Mercer Contest Problem 11: Rover - written in contest

import java.util.*;
public class prob11 {

	public static void main(String[] args) {

		// Process cases.
		Scanner stdin = new Scanner(System.in);
		int numCases = Integer.parseInt(stdin.nextLine());

		for (int loop=0; loop<numCases; loop++) {

			// Read both lines.
			String lineLeft = stdin.nextLine();
			String lineRight = stdin.nextLine();

			// Convert them to "second" arrays.
			int[] left = convert(lineLeft);
			int[] right = convert(lineRight);

			// Trace through positions.
			state start = new state(0, 0, 0);
			for (int i=0; i<left.length; i++) {
				start = move(start, left[i], right[i]);
			}

			// Output end place.
			System.out.printf("%.3f %.3f\n", start.x, start.y);
		}
	}

	// Converts input into second segments.
	public static int[] convert(String line) {

		// Determine the number of segments and the total amount of time.
		int sum = 0;
		StringTokenizer tok = new StringTokenizer(line," |");
		int numSegs = 0;
		while (tok.hasMoreTokens()) {
			int vel = Integer.parseInt(tok.nextToken());
			int t = Integer.parseInt(tok.nextToken());
			sum += t;
			numSegs++;
		}

		// Retokenize and store velocity for each second.
		int[] ans = new int[sum];
		tok = new StringTokenizer(line, " |");
		int index = 0;

		// Go through each segment.
		for (int i=0; i<numSegs; i++) {

			// Here is segment data.
			int vel = Integer.parseInt(tok.nextToken());
			int t = Integer.parseInt(tok.nextToken());

			// Place for each second.
			for (int j=0; j<t; j++)
				ans[index+j] = vel;
			index += t;
		}
		return ans;
	}

	public static state move(state cur, int left, int right) {

		// We just go straight =)
		if (left == right) {
			return new state(cur.x+left*Math.cos(cur.angle),cur.y+right*Math.sin(cur.angle),cur.angle);
		}

		// We turn down.
		else if (left > right) {

			// Figure out how far we go, and both the new robot heading and its perpendicular.
			double r = 1.0*right/(left-right);
			double dAngle = left;
			if (r > 0)
				dAngle = right/r;
			double newA = cur.angle-dAngle;
			double perp = newA+Math.PI/2;

			// Here is the new center of the robot.
			double centerX = cur.x+ (r+.5)*Math.cos(cur.angle-Math.PI/2);
			double centerY = cur.y+(r+.5)*Math.sin(cur.angle-Math.PI/2);

			// Use this and its new angle to calculate where the robot "is".
			return new state(centerX+(r+.5)*Math.cos(perp),centerY+(r+.5)*Math.sin(perp),newA);
		}

		// We turn up.
		else {

			// Figure out how far we go, and both the new robot heading and its perpendicular.
			double r = 1.0*left/(right-left);
			double dAngle = right;
			if (r > 0)
				dAngle = left/r;
			double newA = cur.angle+dAngle;
			double perp = newA-Math.PI/2;

			// Here is the new center of the robot.
			double centerX =cur.x+ (r+.5)*Math.cos(cur.angle+Math.PI/2);
			double centerY = cur.y+(r+.5)*Math.sin(cur.angle+Math.PI/2);

			// Use this and its new angle to calculate where the robot "is".
			return new state(centerX+(r+.5)*Math.cos(perp),centerY+(r+.5)*Math.sin(perp),newA);
		}
	}

}

class state {

	public double x;
	public double y;
	public double angle;

	public state(double myx, double myy, double a) {
		x = myx;
		y = myy;
		angle = a;
	}
	public String toString() {
		return x+" "+y;
	}
}
