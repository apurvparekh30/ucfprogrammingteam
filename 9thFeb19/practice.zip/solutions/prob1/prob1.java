// Arup Guha
// 3/6/2014
// Solution to 2014 Mercer Contest Problem 1: Powerful Numbers

import java.util.*;
import java.math.*;

public class prob1 {

	public static void main(String[] args) {

		Scanner stdin = new Scanner(System.in);
		String s = stdin.next();

		// Go through all input.
		while (!s.equals("0")) {

			// Follow directions.
			BigInteger val = new BigInteger(s);
			BigInteger sum = new BigInteger("0");
			for (int i=1; i<=s.length(); i++) {
				BigInteger digit = new BigInteger(s.substring(i-1,i));
				sum = sum.add(digit.pow(i));
			}

			// Output result.
			if (sum.equals(val))
				System.out.println(val+" is a powerful number.");
			else
				System.out.println(val+" is not a powerful number.");

			// Go to next case.
			s = stdin.next();
		}
	}
}

