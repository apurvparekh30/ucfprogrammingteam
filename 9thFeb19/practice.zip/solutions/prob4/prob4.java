// Arup Guha
// 3/1/2014
// Solution to 2014 Mercer Contest Problem 4: Problematic Public Keys - written in contest

import java.util.*;

public class prob4 {

	// Returns the smallest prime in primes that divides evenly into n.
	public static int getP(int n, int[] primes) {

		for (int i=0; i<primes.length; i++)
			if (n%primes[i] == 0)
				return primes[i];

		return 1; // Should never get here.
	}

	public static void main(String[] args) {

		Scanner stdin = new Scanner(System.in);

		// Run regular prime sieve.
		boolean[] sieve = new boolean[100000];
		Arrays.fill(sieve, true);
		sieve[0] = false;
		sieve[1] = false;
		for (int i=2; i<sieve.length; i++)
			for (int j=2*i; j<sieve.length; j+=i)
				sieve[j] = false;
		int cnt = 0;
		for (int i=0; i<sieve.length; i++)
			if (sieve[i])
				cnt++;

		// Condense answer in array of primes.
		int index = 0;
		int[] primes = new int[cnt];
		for (int i=0; i<sieve.length; i++)
			if (sieve[i])
				primes[index++] = i;

		int numCases = stdin.nextInt();

		// Go through each case.
		for (int loop=0; loop<numCases; loop++) {

			int caseNum = stdin.nextInt();
			int n = stdin.nextInt();

			// Read in numbers.
			int[] vals = new int[n];
			for (int i=0; i<n; i++)
				vals[i] = stdin.nextInt();

			// Go through each number, storing unique prime factors.
			HashSet<Integer> list = new HashSet<Integer>();
			for (int i=0; i<n; i++) {
				int lowP = getP(vals[i], primes);
				list.add(lowP);
				list.add(vals[i]/lowP);
			}

			// Store and sort.
			int[] ans = new int[list.size()];
			index = 0;
			for (Integer a: list)
				ans[index++] = a;
			Arrays.sort(ans);

			// Print out in their annoying format.
			System.out.println(loop+1);
			for (int i=0; i<ans.length; i++) {
				if (i%5 == 0) System.out.print(ans[i]);
				else System.out.print(" "+ans[i]);
				if (i%5 == 4) System.out.println();
			}
			if (ans.length%5 != 0) System.out.println();
		}

	}
}
