// Arup Guha
// 3/17/2014
// Solution to 2014 Mercer Contest Problem 9: Ultimate Tic-Tac-Toe

import java.util.*;

public class prob9 {

	final public static String[] PLAYER = {"one", "two"};

	public static void main(String[] args) {

		Scanner stdin = new Scanner(System.in);
		int numCases = Integer.parseInt(stdin.nextLine().trim());

		// Process each case.
		for (int loop=0; loop<numCases; loop++) {
			String line = stdin.nextLine();
			solve(line);
		}
	}

	public static void solve(String line) {

		StringTokenizer tok = new StringTokenizer(line);
		int id = 0;
		tactoe game = new tactoe();

		int loop = 0;

		// Go through each move.
		while (tok.hasMoreTokens()) {

			// Get this move and play it.
			String move = tok.nextToken();
			boolean res = game.doMove(move, id+1);

			// Process invalid case and get out.
			if (!res) {
				System.out.println("Player "+PLAYER[id]+" made an invalid move on turn "+loop+".");
				return;
			}

			// Update for next move.
			id = 1 - id;
			loop++;
		}

		// If we get here, game worked.
		System.out.println("All moves were valid.");
	}
}

class tactoe {

	final public static int NONE = -1;
	final public static int CATS = 3;

	// Note: 1 = player 1, 2 = player 2, 0 = unfilled.
	private int[][] board;
	private int nummoves;
	private int prevpos;
	private int[] outcome;

	public tactoe() {

		// Stored differently than theirs...1st index is board, 2nd is play.
		board = new int[9][9];
		nummoves = 0;
		prevpos = NONE;
		outcome = new int[9];
	}

	// Attempt moving pos for player turn, return if it's okay or not.
	public boolean doMove(String pos, int turn) {

		// Check validity then move.
		if (isValid(pos)) {
			move(pos, turn);
			nummoves++;
			return true;
		}

		// Oops, invalid!
		return false;
	}

	// Just executes move pos for player turn (w/o checking validity.
	public void move(String pos, int turn) {

		// Get move.
		int row = pos.charAt(0) - '0';
		int col = pos.charAt(1) - '0';

		// Convert coordinates.
		int game = getGame(row, col);
		int posInt = getPos(row, col);

		// Play and update previous position and board outcome.
		board[game][posInt] = turn;
		prevpos = posInt;
		outcome[game]  = getOutcome(board[game], turn);
	}

	// Here is my conversion factor for game number.
	public static int getGame(int row, int col) {
		return 3*(row/3) + col/3;
	}

	// Here is my conversion factor for position number.
	public static int getPos(int row, int col) {
		return 3*(row%3) + col%3;
	}

	// Returns true iff pos is valid, regardless of player.
	public boolean isValid(String pos) {

		// Check if it's on the board.
		int row = pos.charAt(0) - '0';
		int col = pos.charAt(1) - '0';
		if (row < 0 || row >= 9 || col < 0 || col >=9) return false;

		// Convert to my storage scheme.
		int game = getGame(row, col);
		int posInt = getPos(row, col);

		// First move can be anywhere.
		if (prevpos == NONE) {
			return true;
		}
		else {

			// See if forced game is still open.
			if (outcome[prevpos] == 0) {

				// You must play in this game on an open square.
				if (prevpos != game)  return false;
				if (!openSq(board[game], posInt)) return false;
				return true;
			}

			// Otherwise, any open square in any unfinished game is fine.
			else {
				if (outcome[game] != 0) return false;
				if (!openSq(board[game], posInt)) return false;
				return true;
			}
		}
	}

	// Returns true iff pos in the single game game is open.
	public static boolean openSq(int[] game, int pos) {
		return game[pos] == 0;
	}

	// Returns the outcome of game for turn
	public static int getOutcome(int[] game, int turn) {

		// Check rows.
		for (int i=0; i<3; i++) {
			int check = winner(game[3*i], game[3*i+1], game[3*i+2], turn);
			if (check != 0) return check;
		}

		// Check cols.
		for (int i=0; i<3; i++) {
			int check = winner(game[i], game[i+3], game[i+6], turn);
			if (check != 0) return check;
		}

		// Check diag.
		int check = winner(game[0], game[4], game[8], turn);
		if (check != 0) return check;
		check = winner(game[2], game[4], game[6], turn);

		// Look for open square, since no one has won yet.
		for (int i=0; i<9; i++)
			if (game[i] == 0)
				return 0;

		// It's a cats game if we get all the way here.
		return CATS;
	}

	// Returns the winner using the larger game rules for turn.
	public static int winner(int a, int b, int c, int turn) {

		// Add in non-cats game squares.
		ArrayList<Integer> list = new ArrayList<Integer>();
		if (a != CATS) list.add(a);
		if (b != CATS) list.add(b);
		if (c != CATS) list.add(c);

		// Brute force check of all outcomes.
		if (list.contains(0)) return 0;
		if (list.size() == 0) return turn;
		if (list.size() == 1) return list.get(0);

		// Two squares by players - need to check if they're the same.
		if (list.size() == 2) {
			if (list.get(0) == list.get(1)) return list.get(0);
			return 0;
		}

		// All three squares are filled in. If all same, that's the result, else 0.
		if (list.get(0) == list.get(1) && list.get(1) == list.get(2)) return list.get(0);
		return 0;
	}
}
