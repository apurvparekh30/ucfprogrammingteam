// Arup Guha
// 3/2/2014
// Solution to 2014 Mercer Contest Problem: Social Pairings

import java.util.*;

public class prob3 {

	final public static long MOD = 100000007;

	public static void main(String[] args) {

		// Will store all subproblems here.
		// memo[i][j] is the number of ways to match the remaining people in the first group with people
		// in the second group such that i people need 1 more meeting and j people need 2 more meetings
		// in the second group.
		long[][] memo = new long[2001][2001];
		for (int i=0; i<memo.length; i++)
			Arrays.fill(memo[i], -1);

		// Process all cases.
		Scanner stdin = new Scanner(System.in);
		int numCases = stdin.nextInt();
		for (int i=0; i<numCases; i++) {
			int n = stdin.nextInt();
			long ans = f(0, n, memo);
			System.out.println(ans);
		}
	}

	// Solves given problem knowing that we must match ones number of people in group 2 with 1 more person
	// in group 1 and twos number of people in group 2 with 2 more people from group 1. memo stores
	// previously calculated cases.
	public static long f(int ones, int twos, long[][] memo) {

		// We have no more people to meet.
		if (ones == 0 && twos == 0) return 1;

		// We can't meet someone a negative number of times.
		if (ones < 0 || twos < 0) return 0;

		// We've stored this one.
		if (memo[ones][twos] != -1) return memo[ones][twos];

		long sum = 0;

		// Our new person meets two people in the other group who need to meet two people.
		sum = (sum + (choose(twos, 2)*f(ones+2, twos-2, memo)))%MOD;

		// Our new person meets two people in the other group who need to meet one person.
		sum = (sum + (choose(ones, 2)*f(ones-2, twos, memo)))%MOD;

		// Our new person meets one person who needs to meet one person and one person who needs to meet two.
		sum = (sum + (ones*twos*f(ones, twos-1, memo)))%MOD;

		// Store and return.
		memo[ones][twos] = sum;
		return sum;
	}

	// Combo that I know won't overflow in this problem.
	public static long choose(int n, int k) {
		long ans = 1;
		for (int i=n; i>=n-k+1; i--)
			ans *= i;
		for (int i=1; i<=k; i++)
			ans /= i;
		return ans;
	}
}
