// Arup Guha
// 3/6/2014
// Solution to 2014 Mercer Contest Problem 5: Say My Number

import java.util.*;

public class prob5 {

	// Annoying constants.
	final public static String[] ONES = {"zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven",
										 "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen"};

	final public static String[] TENS = {"", "", "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety"};

	final public static String HUNDRED = "hundred";

	final public static String[] POW3 = {"", "thousand", "million", "billion", "trillion", "quadrillion", "quintillion"};

	public static boolean PRINT;

	public static void main(String[] args) {

		Scanner stdin = new Scanner(System.in);
		int numCases = stdin.nextInt();

		// Process each case.
		for (int loop=0; loop<numCases; loop++) {
			long val = stdin.nextLong();
			PRINT = false;
			print(val, 0);
			System.out.println();
		}
	}

	// Prints out value assuming we've chopped off 1000^iter from it already.
	public static void print(long value, int iter) {

		// Recursive case.
		if (value/1000L > 0)
			print(value/1000L, iter+1);

		// Last part.
		int rest = (int)(value%1000L);
		int hundreds = rest/100;
		int last = rest%100;

		// Tricky space...
		if (rest > 0 && PRINT) System.out.print(" ");

		// Printing this segment.

		// See if there is a hundreds component.
		boolean flag = false;
		if (hundreds > 0) {
			System.out.print(ONES[hundreds]+" hundred");
			flag = true;
		}

		// This last component is annoying in English.
		if (last < 20 && last > 0) {
			if (flag) System.out.print(" ");
			System.out.print(ONES[last]);
		}
		else if (last >= 20) {
			if (flag) System.out.print(" ");
			System.out.print(TENS[last/10]);
			if (last%10 > 0) System.out.print(" "+ONES[last%10]);
		}

		// Only print this part if something preceded it.
		if (iter > 0 && rest > 0) System.out.print(" "+POW3[iter]);

		// This is a "global" issue to see if something already printed.
		if (rest > 0) PRINT = true;
	}
}
